document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('signupForm');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const skillInput = document.getElementById('skill');
    const portfolioInput = document.getElementById('portfolio');

    // Validation functions
    const validateName = (name) => {
        const nameRegex = /^[a-zA-Z\s]{2,50}$/;
        return nameRegex.test(name);
    };

    const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    };

    const validatePortfolio = (url) => {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    };

    // Show error message
    const showError = (element, message) => {
        const errorElement = document.getElementById(`${element.id}Error`);
        errorElement.textContent = message;
        errorElement.style.display = 'block';
        element.style.borderColor = '#e74c3c';
    };

    // Hide error message
    const hideError = (element) => {
        const errorElement = document.getElementById(`${element.id}Error`);
        errorElement.style.display = 'none';
        element.style.borderColor = '#e0e0e0';
    };

    // Form submission handler
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        let isValid = true;

        // Validate name
        if (!validateName(nameInput.value)) {
            showError(nameInput, 'Please enter a valid name (2-50 characters, letters only)');
            isValid = false;
        } else {
            hideError(nameInput);
        }

        // Validate email
        if (!validateEmail(emailInput.value)) {
            showError(emailInput, 'Please enter a valid email address');
            isValid = false;
        } else {
            hideError(emailInput);
        }

        // Validate skill
        if (!skillInput.value) {
            showError(skillInput, 'Please select a skill category');
            isValid = false;
        } else {
            hideError(skillInput);
        }

        // Validate portfolio
        if (!validatePortfolio(portfolioInput.value)) {
            showError(portfolioInput, 'Please enter a valid URL');
            isValid = false;
        } else {
            hideError(portfolioInput);
        }

        if (isValid) {
            // Create success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.innerHTML = `
                <i class="fas fa-check-circle"></i>
                <h2>Thank you for joining GigFlow!</h2>
                <p>We've received your application and will review it shortly.</p>
                <p>You'll receive a confirmation email at ${emailInput.value}</p>
            `;

            // Clear form and show success message
            form.style.display = 'none';
            document.querySelector('.form-container').appendChild(successMessage);

            // Add success message styles
            const style = document.createElement('style');
            style.textContent = `
                .success-message {
                    text-align: center;
                    padding: 30px;
                }
                .success-message i {
                    font-size: 4rem;
                    color: #2ecc71;
                    margin-bottom: 20px;
                }
                .success-message h2 {
                    color: #333;
                    margin-bottom: 15px;
                }
                .success-message p {
                    color: #666;
                    margin-bottom: 10px;
                }
            `;
            document.head.appendChild(style);
        }
    });

    // Real-time validation
    nameInput.addEventListener('input', () => {
        if (validateName(nameInput.value)) {
            hideError(nameInput);
        }
    });

    emailInput.addEventListener('input', () => {
        if (validateEmail(emailInput.value)) {
            hideError(emailInput);
        }
    });

    skillInput.addEventListener('change', () => {
        if (skillInput.value) {
            hideError(skillInput);
        }
    });

    portfolioInput.addEventListener('input', () => {
        if (validatePortfolio(portfolioInput.value)) {
            hideError(portfolioInput);
        }
    });
}); 